class Pat3
{
	public static void main(String args[])
	{
		int space,rows=9,k=0;
		for(int i=1;i<=rows;i++)
		{
			for(space=1;space<=(rows-i);space++)
			{
			System.out.print(" ");
			}
			while(k!=(1*i-1))
			{
				System.out.print(" *");
				k++;
			}
			        k=0;
				System.out.println();
		}
	
	}
}