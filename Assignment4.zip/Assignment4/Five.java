class Five
{
    public static void main(String []args)
    {
        Scanner sc=new Scanner(System.in);
        Simpleinterest s=new Simpleinterest();
        
        System.out.println("SI: Rs."+s.CalculateSI());
     }
}