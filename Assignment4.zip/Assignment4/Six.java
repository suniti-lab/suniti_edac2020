class Six
{
    int real;
    int imag;
    Scanner sc=new Scanner(System.in);
    
    Complex()
    {
        System.out.print("Enter Real part: ");
        real=sc.nextInt();
        System.out.print("Enter Imaginary part: ");
        imag=sc.nextInt();
    }
    
    int CalcReal(Complex x)
    {
        int sum=x.real+real;
        return sum;
    }
    
    int CalcImag(Complex x)
    {
        int sum=x.imag+imag;
        return sum;
    }
    
    
}