0class Student 
{ 
    int rollNo; 
    String name;
    int marks;
 
    Student(int rn, String n, int m) 
    { 
        rollNo=rn; 
        name=n;
	marks=m;
    }  
    void display() 
    { 
    System.out.println(rollNo); 
    System.out.println(name); 
    System.out.println(marks); 
    System.out.println(); 
    } 
}
class One
{
	public static void main(String args[])
	{ 
        Student[] arr= new Student[2]; 
        arr[0] = new Student(1, "Ram",100); 
        arr[1] = new Student(2, "Shyam",200); 
  
        System.out.println("Student data in student arr 0: "); 
        arr[0].display(); 
  
        System.out.println("Student data in student arr 1: "); 
        arr[1].display(); 
    } 
} 
	

	
