import java.util.Scanner;
class Book
{
	int bookId;
	String bookName;
	float bookPrice;
        Book()
        {
            
        }
	Book(int id,String bn,float bp)
	{
	bookId=id;
	bookName=bn;
	bookPrice=bp;
	}
	 void fun()
	{
	  System.out.println(bookId);
	  System.out.println(bookName);
	  System.out.println(bookPrice);
	}
	  
}
	
class Two
{
	public static void main(String args[])
	{
	Scanner in = new Scanner(System.in);
        System.out.println("Input number of books:");
	int n = Integer.parseInt(in.nextLine().trim());
	System.out.println("Enter BookID,Book Name and price:");
	Book b= new Book(); 
	Book max=new Book();
	for (int i = 0; i < n; i ++) 
	{
			b.bookId = in.nextInt();
			b.bookName= in.next();
			b.bookPrice = in.nextFloat();
			if (max.bookPrice < b.bookPrice) 
			{
				max.bookId = b.bookId;
				max.bookName = b.bookName;
				max.bookPrice = b.bookPrice;
			}
	
	}
        System.out.println("BookID of the highest price :");
        System.out.println(max.bookPrice);
  }
}



